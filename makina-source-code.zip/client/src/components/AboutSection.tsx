/**
 * AboutSection — Makina Menswear
 * Design: Noir Luxe — dark background, gold accents, brand story
 */

export default function AboutSection() {
  return (
    <section id="about" className="bg-[#0D0D0D] py-20 lg:py-32">
      <div className="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left — Text */}
          <div>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-6 h-[1px] bg-[#C9A84C]" />
              <span className="text-[11px] tracking-[0.3em] text-[#C9A84C] uppercase font-medium">About Us</span>
            </div>
            <h2 className="font-[var(--font-display)] text-3xl sm:text-4xl lg:text-5xl font-bold text-white leading-[1.15] mb-6">
              Crafted for the
              <br />
              <span className="gold-shimmer italic font-normal">Modern Man</span>
            </h2>
            <p className="text-[#999] text-sm sm:text-base leading-relaxed mb-6">
              At Makina Menswear, we believe that style is a statement. Our collection is carefully curated to bring you premium outerwear that combines contemporary design with timeless craftsmanship.
            </p>
            <p className="text-[#999] text-sm sm:text-base leading-relaxed mb-8">
              From our signature Varsity Jackets to sleek Windbreakers and classic Coach Jackets, every piece is designed to elevate your wardrobe and express your individuality.
            </p>
            <div className="grid grid-cols-3 gap-6">
              <div>
                <div className="font-[var(--font-display)] text-2xl lg:text-3xl font-bold gold-text mb-1">10+</div>
                <div className="text-[11px] tracking-[0.15em] text-[#777] uppercase">Styles</div>
              </div>
              <div>
                <div className="font-[var(--font-display)] text-2xl lg:text-3xl font-bold gold-text mb-1">3</div>
                <div className="text-[11px] tracking-[0.15em] text-[#777] uppercase">Categories</div>
              </div>
              <div>
                <div className="font-[var(--font-display)] text-2xl lg:text-3xl font-bold gold-text mb-1">100%</div>
                <div className="text-[11px] tracking-[0.15em] text-[#777] uppercase">Premium</div>
              </div>
            </div>
          </div>

          {/* Right — Visual */}
          <div className="relative">
            <div className="aspect-[4/5] bg-[#161616] overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1617137968427-85924c800a22?w=800&q=80"
                alt="Makina Menswear - Premium Fashion"
                className="w-full h-full object-cover opacity-80"
                loading="lazy"
              />
            </div>
            {/* Gold accent frame */}
            <div className="absolute -bottom-4 -right-4 w-full h-full border border-[#C9A84C]/30 -z-10" />
          </div>
        </div>
      </div>
    </section>
  );
}
