/**
 * CollectionSection — Makina Menswear
 * Design: Noir Luxe — white/light background for product grid (matching original)
 * Section title: "— OUR COLLECTION" / "New Season Arrivals" (Arrivals in italic)
 * Products grouped by category with 2-col grid
 */

import { getCategories } from "@/lib/products";
import ProductCard from "./ProductCard";

export default function CollectionSection() {
  const categories = getCategories();

  return (
    <section id="collection" className="bg-white py-16 lg:py-24">
      <div className="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-14 lg:mb-20">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-6 h-[1px] bg-[#1a1a1a]" />
            <span className="text-[11px] tracking-[0.3em] text-[#888] uppercase font-medium">Our Collection</span>
          </div>
          <div className="flex items-start justify-between">
            <h2 className="font-[var(--font-display)] text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1a1a1a] leading-[1.15]">
              New Season
              <br />
              <span className="italic font-normal">Arrivals</span>
            </h2>
            <a
              href="/shop"
              className="hidden sm:inline-flex items-center gap-2 mt-2 px-5 py-2.5 border border-[#1a1a1a] text-[#1a1a1a] text-xs tracking-[0.2em] uppercase font-semibold hover:bg-[#1a1a1a] hover:text-white transition-all duration-300"
            >
              Shop All
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </a>
          </div>
        </div>

        {/* Categories */}
        <div className="space-y-16 lg:space-y-24">
          {categories.map((category) => (
            <div key={category.slug}>
              {/* Category Title */}
              <div className="mb-8 pb-4 border-b border-[#e5e5e5]">
                <h3 className="font-[var(--font-display)] text-xl lg:text-2xl font-semibold text-[#1a1a1a]">
                  {category.name}
                </h3>
              </div>

              {/* Product Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
                {category.products.map((product, idx) => (
                  <ProductCard key={product.id} product={product} index={idx} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
