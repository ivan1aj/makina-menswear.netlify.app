/**
 * Footer — Makina Menswear
 * Design: Noir Luxe — dark footer with gold accents
 * Contact: +31 6 57505640 / marksafarnl@gmail.com
 */

import { Instagram, Phone, Mail, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer id="contact" className="bg-[#080808] border-t border-white/5">
      {/* Main Footer */}
      <div className="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#C9A84C] to-[#E8D48B] flex items-center justify-center">
                <span className="text-[#0A0A0A] font-[var(--font-display)] font-bold text-sm">M</span>
              </div>
              <div className="leading-tight">
                <span className="gold-shimmer font-[var(--font-display)] font-bold text-base tracking-wide">MAKINA</span>
                <span className="block text-[10px] tracking-[0.25em] text-[#888] font-medium uppercase">Menswear</span>
              </div>
            </div>
            <p className="text-[#777] text-sm leading-relaxed max-w-xs">
              Premium men's outerwear for the modern gentleman. Elevate your style with our curated collection.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-[11px] tracking-[0.25em] text-[#C9A84C] uppercase font-semibold mb-5">Quick Links</h4>
            <nav className="flex flex-col gap-3">
              <a href="#collection" className="text-sm text-[#888] hover:text-[#C9A84C] transition-colors">Collection</a>
              <a href="#about" className="text-sm text-[#888] hover:text-[#C9A84C] transition-colors">About</a>
              <a href="#contact" className="text-sm text-[#888] hover:text-[#C9A84C] transition-colors">Contact</a>
            </nav>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-[11px] tracking-[0.25em] text-[#C9A84C] uppercase font-semibold mb-5">Categories</h4>
            <nav className="flex flex-col gap-3">
              <a href="#collection" className="text-sm text-[#888] hover:text-[#C9A84C] transition-colors">Varsity Jackets</a>
              <a href="#collection" className="text-sm text-[#888] hover:text-[#C9A84C] transition-colors">Windbreakers</a>
              <a href="#collection" className="text-sm text-[#888] hover:text-[#C9A84C] transition-colors">Coach Jackets</a>
            </nav>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-[11px] tracking-[0.25em] text-[#C9A84C] uppercase font-semibold mb-5">Contact Us</h4>
            <div className="flex flex-col gap-4">
              <a
                href="tel:+31657505640"
                className="flex items-center gap-3 text-sm text-[#888] hover:text-[#C9A84C] transition-colors"
              >
                <Phone className="w-4 h-4 text-[#C9A84C] shrink-0" />
                +31 6 57505640
              </a>
              <a
                href="mailto:marksafarnl@gmail.com"
                className="flex items-center gap-3 text-sm text-[#888] hover:text-[#C9A84C] transition-colors"
              >
                <Mail className="w-4 h-4 text-[#C9A84C] shrink-0" />
                marksafarnl@gmail.com
              </a>
              <a
                href="https://instagram.com/makinamenswear"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-sm text-[#888] hover:text-[#C9A84C] transition-colors"
              >
                <Instagram className="w-4 h-4 text-[#C9A84C] shrink-0" />
                @MakinaMenswear
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5">
        <div className="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[11px] text-[#555] tracking-wider">
            &copy; {new Date().getFullYear()} Makina Menswear. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <a href="https://instagram.com/makinamenswear" target="_blank" rel="noopener noreferrer" className="text-[#555] hover:text-[#C9A84C] transition-colors">
              <Instagram className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
