/**
 * HeroSection — Makina Menswear
 * Design: Full-bleed cinematic hero matching brand reference
 */

import { useEffect, useRef } from "react";

const HERO_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663414378770/gTh3jEuyLXkAMMkPrHCcP8/hero-banner-Ua7DYk8iReUDmLJcvJESsH.webp";

export default function HeroSection() {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (heroRef.current) {
        const scrollY = window.scrollY;
        const img = heroRef.current.querySelector(".hero-img") as HTMLElement;
        if (img) {
          img.style.transform = `scale(1.08) translateY(${scrollY * 0.15}px)`;
        }
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <section ref={heroRef} className="relative w-full h-screen overflow-hidden">
      {/* Background Image — full bleed */}
      <div className="hero-img absolute inset-0 scale-[1.08] will-change-transform">
        <img
          src={HERO_IMAGE}
          alt="Makina Menswear"
          className="w-full h-full object-cover object-center"
        />
      </div>

      {/* Gradient overlays for depth */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/85" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/30 via-transparent to-transparent" />

      {/* Content — positioned at bottom left like the reference */}
      <div className="relative h-full flex flex-col justify-end px-6 pb-14 lg:px-12 lg:pb-20 max-w-[1400px] mx-auto">
        <div>
          {/* Eyebrow line */}
          <div className="flex items-center gap-4 mb-5">
            <div className="w-10 h-[1px] bg-[#C9A84C]" />
            <span className="text-[#C9A84C] text-[10px] tracking-[0.4em] uppercase font-semibold">
              Premium Collection
            </span>
          </div>

          {/* Main headline */}
          <h1 className="font-[var(--font-display)] text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-[1.05] mb-5">
            Elevate Your
            <br />
            <span className="gold-shimmer">Style</span>
          </h1>

          {/* Subtext */}
          <p className="text-white/60 text-sm sm:text-base max-w-sm leading-relaxed mb-10 font-light">
            Discover our curated collection of premium men's outerwear. Crafted for those who demand excellence.
          </p>

          {/* CTA */}
          <a
            href="/shop"
            className="inline-flex items-center gap-4 px-9 py-4 bg-gradient-to-r from-[#C9A84C] to-[#A88B3A] text-[#0A0A0A] text-[11px] tracking-[0.3em] uppercase font-bold hover:from-[#E8D48B] hover:to-[#C9A84C] transition-all duration-300 shadow-xl shadow-[#C9A84C]/25"
          >
            Shop Now
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
}
