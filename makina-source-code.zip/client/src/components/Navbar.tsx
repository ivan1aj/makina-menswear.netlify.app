/**
 * Navbar — Makina Menswear
 * Design: Transparent over hero, solid on scroll — matching brand reference
 */

import { useState, useEffect } from "react";
import { Menu, X, Instagram } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();
  const isShop = location === "/shop";

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled || isShop
          ? "bg-[#0A0A0A]/97 backdrop-blur-xl border-b border-white/6 shadow-2xl shadow-black/60"
          : "bg-transparent border-b border-transparent"
      }`}
    >
      <div className="max-w-[1400px] mx-auto px-5 sm:px-8 lg:px-12">
        <div className="flex items-center justify-between h-[68px] lg:h-[76px]">

          {/* Logo */}
          <Link href="/" className="flex items-center gap-3.5 group">
            {/* Gold circle with M */}
            <div className="relative w-10 h-10 rounded-full flex-shrink-0">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-[#E8D48B] via-[#C9A84C] to-[#A88B3A]" />
              <span className="absolute inset-0 flex items-center justify-center text-[#0A0A0A] font-black text-base">
                M
              </span>
            </div>
            {/* Brand name */}
            <div className="leading-none">
              <div className="text-[#C9A84C] font-black text-base tracking-[0.12em] leading-none">
                MAKINA
              </div>
              <div className="text-[#888] text-[9px] tracking-[0.4em] font-medium uppercase mt-[3px]">
                Menswear
              </div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-10">
            {isShop ? (
              <Link href="/" className="nav-link">Home</Link>
            ) : (
              <a href="#collection" className="nav-link">Collection</a>
            )}
            <Link
              href="/shop"
              className={`nav-link ${isShop ? "!text-[#C9A84C]" : ""}`}
            >
              Shop
            </Link>
            <a href={isShop ? "/#about" : "#about"} className="nav-link">About</a>
            <a href={isShop ? "/#contact" : "#contact"} className="nav-link">Visit Us</a>
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-5">
            <a
              href="https://instagram.com/makinamenswear"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-2 text-[10px] tracking-[0.2em] text-[#777] hover:text-[#C9A84C] transition-colors duration-300 uppercase"
            >
              <Instagram className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">@MakinaMenswear</span>
            </a>

            {/* Mobile toggle */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden text-[#aaa] hover:text-white transition-colors p-1"
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-[#0A0A0A] border-t border-white/6">
          <nav className="flex flex-col px-6 py-8 gap-6">
            <Link href="/" onClick={() => setMobileOpen(false)} className="mobile-nav-link">Home</Link>
            <Link href="/shop" onClick={() => setMobileOpen(false)} className="mobile-nav-link !text-[#C9A84C] font-bold">Shop All</Link>
            <a href="#about" onClick={() => setMobileOpen(false)} className="mobile-nav-link">About</a>
            <a href="#contact" onClick={() => setMobileOpen(false)} className="mobile-nav-link">Visit Us</a>
            <div className="pt-4 border-t border-white/6">
              <a
                href="https://instagram.com/makinamenswear"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-sm tracking-[0.15em] text-zinc-500 hover:text-[#C9A84C] transition-colors"
              >
                <Instagram className="w-4 h-4" />
                @MakinaMenswear
              </a>
            </div>
          </nav>
        </div>
      )}

      <style>{`
        .nav-link {
          font-size: 11px;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          font-weight: 500;
          color: #aaa;
          transition: color 0.3s;
          position: relative;
          padding-bottom: 2px;
        }
        .nav-link:hover { color: #C9A84C; }
        .nav-link::after {
          content: '';
          position: absolute;
          bottom: -2px;
          left: 0;
          width: 0;
          height: 1px;
          background: #C9A84C;
          transition: width 0.3s;
        }
        .nav-link:hover::after { width: 100%; }
        .mobile-nav-link {
          font-size: 13px;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          font-weight: 500;
          color: #ccc;
          transition: color 0.3s;
        }
        .mobile-nav-link:hover { color: #C9A84C; }
      `}</style>
    </header>
  );
}
