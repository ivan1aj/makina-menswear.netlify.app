/**
 * ProductCard — Makina Menswear
 * Design: Noir Luxe — elegant product card with hover effects and gold accents
 * Supports colorVariants: clicking a colour swatch changes the displayed image
 */

import { useState } from "react";
import { Link } from "wouter";
import type { Product } from "@/lib/products";

interface ProductCardProps {
  product: Product;
  index: number;
}

const COLOR_MAP: Record<string, string> = {
  black: "#0A0A0A",
  white: "#F5F5F5",
  grey: "#9E9E9E",
  gray: "#9E9E9E",
  navy: "#1B2A4A",
  blue: "#2563EB",
  red: "#DC2626",
  green: "#16A34A",
  teal: "#0D9488",
  beige: "#C8A97E",
  camel: "#C19A6B",
  brown: "#92400E",
  orange: "#EA580C",
  mint: "#6EE7B7",
  cream: "#FFF8E7",
  pink: "#EC4899",
  purple: "#7C3AED",
  yellow: "#EAB308",
};

export default function ProductCard({ product, index }: ProductCardProps) {
  const hasVariants = !!(product.colorVariants && product.colorVariants.length > 0);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [activeVariantIdx, setActiveVariantIdx] = useState(0);

  const displayImage = hasVariants
    ? product.colorVariants![activeVariantIdx].image
    : product.image;

  const handleColorClick = (e: React.MouseEvent, idx: number) => {
    e.preventDefault();
    e.stopPropagation();
    setImageLoaded(false);
    setActiveVariantIdx(idx);
  };

  const discount = product.oldPrice > product.newPrice
    ? Math.round(((product.oldPrice - product.newPrice) / product.oldPrice) * 100)
    : 0;

  return (
    <Link
      href={`/product/${product.id}`}
      className="group block"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      {/* Image Container */}
      <div className="relative overflow-hidden bg-[#111] aspect-[3/4] mb-4 rounded-lg">
        {/* Badges */}
        <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5">
          {product.isNew && (
            <span className="bg-white text-[#0A0A0A] px-2.5 py-1 text-[9px] tracking-[0.2em] font-bold uppercase rounded-sm">
              New
            </span>
          )}
          {discount >= 20 && (
            <span className="bg-[#C9A84C] text-[#0A0A0A] px-2.5 py-1 text-[9px] tracking-[0.15em] font-bold uppercase rounded-sm">
              −{discount}%
            </span>
          )}
        </div>

        {/* Product Image */}
        <img
          src={displayImage}
          alt={product.name}
          className={`w-full h-full object-cover object-top transition-all duration-700 group-hover:scale-[1.04] ${
            imageLoaded ? "opacity-100" : "opacity-0"
          }`}
          onLoad={() => setImageLoaded(true)}
          loading="lazy"
        />

        {/* Loading skeleton */}
        {!imageLoaded && (
          <div className="absolute inset-0 bg-[#161616] animate-pulse" />
        )}

        {/* Hover Overlay — subtle gold border */}
        <div className="absolute inset-0 border border-[#C9A84C]/0 group-hover:border-[#C9A84C]/40 transition-all duration-500 rounded-lg pointer-events-none" />

        {/* Quick View CTA */}
        <div className="absolute inset-x-0 bottom-0 translate-y-full group-hover:translate-y-0 transition-transform duration-400 ease-out">
          <div className="bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/90 to-transparent pt-8 pb-4 px-4">
            <span className="text-[10px] tracking-[0.3em] text-white/90 uppercase font-medium flex items-center gap-2">
              View Details
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </span>
          </div>
        </div>
      </div>

      {/* Product Info */}
      <div className="px-0.5">
        <span className="text-[9px] tracking-[0.3em] text-[#C9A84C]/80 uppercase font-semibold block mb-1">
          {product.category}
        </span>
        <h3 className="text-sm text-white font-medium mb-2.5 leading-snug group-hover:text-[#C9A84C] transition-colors duration-300">
          {product.name}
        </h3>

        {/* Price */}
        <div className="flex items-baseline gap-2.5 mb-3">
          <span className="text-base font-bold text-white">
            €{product.newPrice.toFixed(2)}
          </span>
          <span className="text-xs text-zinc-600 line-through">
            €{product.oldPrice.toFixed(2)}
          </span>
        </div>

        {/* Colour Swatches — only for products with colorVariants */}
        {hasVariants && (
          <div className="flex items-center gap-2 flex-wrap">
            {product.colorVariants!.map((variant, idx) => {
              const cssColor = COLOR_MAP[variant.color.toLowerCase()] ?? variant.color;
              const isActive = idx === activeVariantIdx;
              return (
                <button
                  key={variant.color}
                  title={variant.label}
                  onClick={(e) => handleColorClick(e, idx)}
                  className={`w-5 h-5 rounded-full transition-all duration-200 ${
                    isActive
                      ? "ring-2 ring-[#C9A84C] ring-offset-2 ring-offset-[#080808] scale-110"
                      : "ring-1 ring-zinc-700 hover:ring-zinc-500"
                  }`}
                  style={{ backgroundColor: cssColor }}
                />
              );
            })}
          </div>
        )}

        {/* Simple color dots for non-variant products with multiple colors */}
        {!hasVariants && product.colors && product.colors.length > 1 && (
          <div className="flex items-center gap-1.5">
            {product.colors.slice(0, 5).map((color) => {
              const cssColor = COLOR_MAP[color.toLowerCase()] ?? "#888";
              return (
                <div
                  key={color}
                  className="w-3 h-3 rounded-full ring-1 ring-zinc-700"
                  style={{ backgroundColor: cssColor }}
                  title={color}
                />
              );
            })}
            {product.colors.length > 5 && (
              <span className="text-[10px] text-zinc-600">+{product.colors.length - 5}</span>
            )}
          </div>
        )}
      </div>
    </Link>
  );
}
