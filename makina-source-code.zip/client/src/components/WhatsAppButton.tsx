/**
 * WhatsAppButton — Floating WhatsApp contact button
 * Design: Noir Luxe — green WhatsApp button with pulse animation
 * Phone: +31 6 57505640
 */

import { useState } from "react";
import { MessageCircle, X } from "lucide-react";

export default function WhatsAppButton() {
  const [showTooltip, setShowTooltip] = useState(false);

  const whatsappUrl = "https://wa.me/31657505640?text=Hi!%20I'm%20interested%20in%20your%20collection.";

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      {/* Tooltip */}
      {showTooltip && (
        <div className="bg-white text-[#1a1a1a] px-4 py-3 rounded-lg shadow-2xl text-sm max-w-[220px] animate-fade-in-up relative">
          <button
            onClick={() => setShowTooltip(false)}
            className="absolute -top-2 -right-2 w-5 h-5 bg-[#333] text-white rounded-full flex items-center justify-center"
          >
            <X className="w-3 h-3" />
          </button>
          <p className="font-medium mb-1">Need help?</p>
          <p className="text-[#666] text-xs">Chat with us on WhatsApp for quick assistance!</p>
        </div>
      )}

      {/* WhatsApp Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        onMouseEnter={() => setShowTooltip(true)}
        className="group relative w-14 h-14 bg-[#25D366] hover:bg-[#20BD5A] rounded-full flex items-center justify-center shadow-lg shadow-[#25D366]/30 hover:shadow-[#25D366]/50 transition-all duration-300 hover:scale-110"
      >
        {/* Pulse ring */}
        <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-20" />
        <MessageCircle className="w-6 h-6 text-white relative z-10" />
      </a>
    </div>
  );
}
