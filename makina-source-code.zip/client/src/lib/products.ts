/**
 * Product data for Makina Menswear
 * Design: Noir Luxe — Dark Editorial Fashion
 * Full product catalog with colors, sizes, descriptions
 */

export interface ColorVariant {
  color: string;       // e.g. "green"
  label: string;       // e.g. "Green"
  image: string;       // main image for this color
  images?: string[];   // extra images for this color
}

export interface Product {
  id: string;
  name: string;
  category: string;
  categorySlug: string;
  oldPrice: number;
  newPrice: number;
  image: string;
  images?: string[];
  colors?: string[];
  colorVariants?: ColorVariant[];  // NEW: per-color images
  sizes?: string[];
  description?: string;
  isNew?: boolean;
}

export interface Category {
  name: string;
  slug: string;
  products: Product[];
}

const PRODUCTS: Product[] = [
  // ─── Puffer Jackets ───────────────────────────────────────────────────────
  {
    id: "puffer-grey",
    name: "Grey Puffer Jacket",
    category: "Jackets",
    categorySlug: "jackets",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["grey"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Premium puffer jacket with a warm insulated fill. Features a zip-up front, ribbed cuffs, and a sleek silhouette perfect for cold weather.",
    image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/BohPLSCdHpCrnbKd.jpg?Expires=1804528152&Signature=otGAkREDJfX7RqOQ6cxKYyyWwJI8jgHVmOgthnjatDstyLtvKEcuZCA-yWMYssC-k14hH60Jot-vNveLdzNr2HgfPiTqT-rWk~WM1ESAvn0SWrQnGiah1rjWXyMJ4Lyu5RF1qU-WRGxd9m2cdWF4PTeSw0tvX0wKd92ISnV92KGy0GDhgL41nN8KytAlRoOxRRYFtwjksubTm5wuZuhC2D9dVP9yWV9DDb8B9B9FtBQIr5WNnE7b60vG~OiZJ~3PzTW4mOpftHFSn5hp2fNJhp9NtbEKur37l3FEgDTUsPvRQ8Zagw4ojfsfZ7xoA7Q77P1OtUHp6nwI0tuNUY7shw__&Key-Pair-Id=K2HSFNDJXOU9YS",
    images: [
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/BohPLSCdHpCrnbKd.jpg?Expires=1804528152&Signature=otGAkREDJfX7RqOQ6cxKYyyWwJI8jgHVmOgthnjatDstyLtvKEcuZCA-yWMYssC-k14hH60Jot-vNveLdzNr2HgfPiTqT-rWk~WM1ESAvn0SWrQnGiah1rjWXyMJ4Lyu5RF1qU-WRGxd9m2cdWF4PTeSw0tvX0wKd92ISnV92KGy0GDhgL41nN8KytAlRoOxRRYFtwjksubTm5wuZuhC2D9dVP9yWV9DDb8B9B9FtBQIr5WNnE7b60vG~OiZJ~3PzTW4mOpftHFSn5hp2fNJhp9NtbEKur37l3FEgDTUsPvRQ8Zagw4ojfsfZ7xoA7Q77P1OtUHp6nwI0tuNUY7shw__&Key-Pair-Id=K2HSFNDJXOU9YS",
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/prWPfyumrevdPevL.jpg?Expires=1804528152&Signature=sX9hrkajtZlnJFLrxYNAadN9ya9G1SODyczDLqkNnwHr1F8gsC5PwEZkOUqIjasm8hwrQCNxQJqTJm3tQn~BX0ou6Y~d4BlWvxlghZiLlK0pbi1pLCo3A0-l5JZ1YyRH0WSvZdLlVljZ5oy1SCN9F93c5fsGUzLubRPnFffWqt7SwVtowdLIS3fsG-jbCRXTrg0g2ndOZp8-Y5tbe7c1FmIJas0VoMvJvh116q8ifDYohZ0kEb~1fzZFmc~L1l5Yssb4vDY3CeiqjaWx28iS6SA1s4SeTNvaODcremjWkmKBsbkH7CLDiTBEoDsZDk1JE7mIu0Mbg-X~FK8k-ralrw__&Key-Pair-Id=K2HSFNDJXOU9YS",
    ],
  },
  {
    id: "puffer-blue",
    name: "Blue Puffer Jacket",
    category: "Jackets",
    categorySlug: "jackets",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["blue"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Bold blue puffer jacket with a modern oversized fit. Water-resistant shell with a cozy insulated interior, ideal for urban style.",
    image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/maqEFqGtiAoNXRCz.jpg?Expires=1804528151&Signature=oZfTWCvn-1NQq-LCm3N4MDdmj4~WzqgF5mpXsAQCo1YKWL0D-XTBemxy9s3CKVhHWIiGNtURVzK8uVeoUTbQuZc6a8AMCmed1qqHJsY5NVcOyPj3Bx2djsdvdQXHxHEGPyrbfN4dxCXRpodjGvDEbxdVQSdkYQjf2UiPK48UU9kC~IuU0NOy8jsklU0CURvaXYdQyrlrU791kechmphpyA6kN79O5ruTDOWOuis3eRkWZhSf1nLcnJtEEapfJJd6ejSIxc~pe91mAjeAk8~kXzMqWC7XEJ8l3NoVu6Je1Ix9PEPs7nSR2XJFdIVt~EjmSRUXRJMUuIxzmzaXZmAXzw__&Key-Pair-Id=K2HSFNDJXOU9YS",
    images: [
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/maqEFqGtiAoNXRCz.jpg?Expires=1804528151&Signature=oZfTWCvn-1NQq-LCm3N4MDdmj4~WzqgF5mpXsAQCo1YKWL0D-XTBemxy9s3CKVhHWIiGNtURVzK8uVeoUTbQuZc6a8AMCmed1qqHJsY5NVcOyPj3Bx2djsdvdQXHxHEGPyrbfN4dxCXRpodjGvDEbxdVQSdkYQjf2UiPK48UU9kC~IuU0NOy8jsklU0CURvaXYdQyrlrU791kechmphpyA6kN79O5ruTDOWOuis3eRkWZhSf1nLcnJtEEapfJJd6ejSIxc~pe91mAjeAk8~kXzMqWC7XEJ8l3NoVu6Je1Ix9PEPs7nSR2XJFdIVt~EjmSRUXRJMUuIxzmzaXZmAXzw__&Key-Pair-Id=K2HSFNDJXOU9YS",
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/aBIohCTtbFOqqplS.jpg?Expires=1804528151&Signature=GGgxfKPB71TwB6objCkh2Uv62m3P4aX1ILDJSyzHs-zk5e49H4pLbKtEH7hnDSJR36jnMs-6VLPJzpvNyncCYTAxdzCsT6R2kxblK~nX-C1Gb3SlpYZS~Mhh7~SUIjE1GIr1K9zdkpS1BdmXMDckc99p9ECp6uuCFiAX1NIOOai409oA02y3nhlZvbWzP3yM~oiKDy8aJ4BnppFjfN4kpTF~BI8KwBW2FrLl9hnlEYJcv2zIgd4Xs-1sUR0PNkvzTScUVU0u~~gRJ-XqKEVIwss3zjhiWH8bH2Ny7V6a~gQZpG7jn7wtMsrprEgbbtjRVkMfQ7LoOn2kt0Vy0KdlaA__&Key-Pair-Id=K2HSFNDJXOU9YS",
    ],
  },

  // ─── Parka Coats ──────────────────────────────────────────────────────────
  {
    id: "parka-white",
    name: "White Parka Coat",
    category: "Jackets",
    categorySlug: "jackets",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["white"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Clean white parka coat with a relaxed fit. Features a drawstring hood, multiple pockets, and a durable outer shell for everyday wear.",
    image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/SoGxSQuQJNmkbumx.jpg?Expires=1804528149&Signature=e21wYl3SLOdCqeTgqtS45G3mz8FhgTpdfmtN2XXu6bx62z7Ekb6G8uyoqjRbX4UFKvtxo7mb92Jhwv8EGa2k5sjdx7O~t9XJ~G3zxgXh06H6KDi-SsupUS9kZavjHi8HV4NvObhN8BYKMT2A5kaZ625T1m3QArgmDWcv7WUR8KdUvltbJFKHFUje747t9tjPwwe5NncBcvoPZPaEeXBCQzGhN0o7Y7CLh3S3Dk2peYqp~NJHbjiQHJLKOtYtpOgQ3AsQFdFj-C0M3MfKwuJhqFHxN9eA9Y~llVhXrtr-AGD5wyteSlk2YESirvSilMrb-6RIFIRPoGo3kcv~Og754w__&Key-Pair-Id=K2HSFNDJXOU9YS",
    images: [
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/SoGxSQuQJNmkbumx.jpg?Expires=1804528149&Signature=e21wYl3SLOdCqeTgqtS45G3mz8FhgTpdfmtN2XXu6bx62z7Ekb6G8uyoqjRbX4UFKvtxo7mb92Jhwv8EGa2k5sjdx7O~t9XJ~G3zxgXh06H6KDi-SsupUS9kZavjHi8HV4NvObhN8BYKMT2A5kaZ625T1m3QArgmDWcv7WUR8KdUvltbJFKHFUje747t9tjPwwe5NncBcvoPZPaEeXBCQzGhN0o7Y7CLh3S3Dk2peYqp~NJHbjiQHJLKOtYtpOgQ3AsQFdFj-C0M3MfKwuJhqFHxN9eA9Y~llVhXrtr-AGD5wyteSlk2YESirvSilMrb-6RIFIRPoGo3kcv~Og754w__&Key-Pair-Id=K2HSFNDJXOU9YS",
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/wfHiltcKxIWlWBXM.jpg?Expires=1804528149&Signature=Jah7ItS9egJklvcEkrc1PTNbmjnNw22RPZCdwpkTzzbC-z0Nvv9hJ-ej6D9woQ-d6K7i3tEqBNaOf3OxNWppaa~GfGR688RlV0mIGmtiPda0EXc0NpzIKVFv21bKFBwuf3jiI5b06-dZ7utxgfvoNLNBbhgsxrI3KVHHeIvYAM1MLB31oN1oHxywfk0km0SzBQeBphbEi9BE-~NJxELlfcicgman4cbszl6niigOtx~DdqgO6qxvwYsYChWy9cJ6gbNg6GPPyy~uMWkFM6-F37lRd4k8JSF65jbYd~F~tJtuvUESYD~O0g3hTKm33LhysSthazT0PMY51mXovY20DA__&Key-Pair-Id=K2HSFNDJXOU9YS",
    ],
  },
  {
    id: "parka-camel",
    name: "Camel Parka Coat",
    category: "Jackets",
    categorySlug: "jackets",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["camel"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Elegant camel parka coat with a timeless design. Warm and stylish, perfect for layering during the colder months.",
    image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/wfHiltcKxIWlWBXM.jpg?Expires=1804528149&Signature=Jah7ItS9egJklvcEkrc1PTNbmjnNw22RPZCdwpkTzzbC-z0Nvv9hJ-ej6D9woQ-d6K7i3tEqBNaOf3OxNWppaa~GfGR688RlV0mIGmtiPda0EXc0NpzIKVFv21bKFBwuf3jiI5b06-dZ7utxgfvoNLNBbhgsxrI3KVHHeIvYAM1MLB31oN1oHxywfk0km0SzBQeBphbEi9BE-~NJxELlfcicgman4cbszl6niigOtx~DdqgO6qxvwYsYChWy9cJ6gbNg6GPPyy~uMWkFM6-F37lRd4k8JSF65jbYd~F~tJtuvUESYD~O0g3hTKm33LhysSthazT0PMY51mXovY20DA__&Key-Pair-Id=K2HSFNDJXOU9YS",
  },

  // ─── Plaid Jacket (NEW) ───────────────────────────────────────────────────
  {
    id: "jacket-plaid-red",
    name: "Red Plaid Flannel Jacket",
    category: "Jackets",
    categorySlug: "jackets",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["red", "black"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Bold red and black plaid flannel jacket with a zip-up front and hoodie layering detail. A statement piece for street-style looks.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/EDMlcVGPHTiSeNXe.jpg",
    images: [
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/EDMlcVGPHTiSeNXe.jpg",
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/tbZsGTxScoMuPEsu.jpg",
    ],
  },

  // ─── Hoodies ──────────────────────────────────────────────────────────────
  {
    id: "hoodie-magic-black",
    name: "Magic On The Field Hoodie",
    category: "Hoodies",
    categorySlug: "hoodies",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["black"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Premium oversized hoodie with a bold graphic print on the back. Heavy-weight cotton blend with a relaxed fit and kangaroo pocket.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/QewBXOoFjHwqopxd.jpg",
    images: [
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/QewBXOoFjHwqopxd.jpg",
    ],
  },
  {
    id: "hoodie-basic",
    name: "Premium Basic Hoodie",
    category: "Hoodies",
    categorySlug: "hoodies",
    oldPrice: 50.99,
    newPrice: 40.99,
    colors: ["green", "blue", "teal", "beige", "white"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Premium heavyweight hoodie with a relaxed fit and kangaroo pocket. Available in multiple colours — select your favourite below.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/kOexGKKcfiucIhbk.jpg",
    colorVariants: [
      {
        color: "green",
        label: "Green",
        image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/kOexGKKcfiucIhbk.jpg",
      },
      {
        color: "blue",
        label: "Blue",
        image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/LhbalhzXozCUFSFw.jpg",
      },
      {
        color: "teal",
        label: "Teal",
        image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/iYJPnIMEIfVxsBPa.jpg",
      },
      {
        color: "beige",
        label: "Beige",
        image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/eEAkVtrkXYUsMGkw.jpg",
      },
      {
        color: "white",
        label: "White",
        image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/cRAZXWrLNzRMNUDZ.jpg",
      },
    ],
  },

  // ─── Shearling Vests ──────────────────────────────────────────────────────
  {
    id: "shearling-white",
    name: "White Shearling Vest",
    category: "Jackets",
    categorySlug: "jackets",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["white"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Luxurious white shearling vest with a plush interior lining. A versatile layering piece that adds warmth and texture to any outfit.",
    image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/cIuRTEjuUkMCsusk.jpg?Expires=1804528151&Signature=GzJ1kaNRMsWHGDZk7fpKEycHbr4kIBku6VZRFyLFuZFJBh6N-ZQDBhTbZsvUa5PL7nQWL1Bz64lrzIbVYNxBF882Lw0h2TDW91VFXvjeY3DJoGWQEl~EPixefBKWjI2DOZ0N0B0sdOlG6mc4IIOSzYnOVBpUmNHXwRIVFGoFZKXJOQ1wXZM4iaisBLdrsGYNUeboskX9jtBIA0Sz0sASBp6fdmaG38WmoBmnv59H5bM0pKoxhvlj0QQiF9fkqt2UlisWOmJLYr9WKUV1H6fwHQq1FwZB~x0U6sKcOS4O6b6CCK34yWrOYLgpWQ~S-WPO1Um4xAnB~EDwSaNd2CJ5Jg__&Key-Pair-Id=K2HSFNDJXOU9YS",
    images: [
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/cIuRTEjuUkMCsusk.jpg?Expires=1804528151&Signature=GzJ1kaNRMsWHGDZk7fpKEycHbr4kIBku6VZRFyLFuZFJBh6N-ZQDBhTbZsvUa5PL7nQWL1Bz64lrzIbVYNxBF882Lw0h2TDW91VFXvjeY3DJoGWQEl~EPixefBKWjI2DOZ0N0B0sdOlG6mc4IIOSzYnOVBpUmNHXwRIVFGoFZKXJOQ1wXZM4iaisBLdrsGYNUeboskX9jtBIA0Sz0sASBp6fdmaG38WmoBmnv59H5bM0pKoxhvlj0QQiF9fkqt2UlisWOmJLYr9WKUV1H6fwHQq1FwZB~x0U6sKcOS4O6b6CCK34yWrOYLgpWQ~S-WPO1Um4xAnB~EDwSaNd2CJ5Jg__&Key-Pair-Id=K2HSFNDJXOU9YS",
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/kawhhqwBlOpRcFKt.jpg?Expires=1804528150&Signature=FmG8AFbdy4fyukaURfFbw2GGYcMMkI6bdaET-lEmjkA4sa9~50vYXO937AoZT2jsqCtUfXOHULyLIBqksQKazjm6iG-lLYq-IhUewVc-BTV7i2lCVU9ZmORlFRGWWwUy3nbZs8WsTTd7KUCrJ1bXs2pey4qjAuxnfNbWYgvlonqT4Kh2VaL0BdFtoXuYXwUt9YCRcd2blAtZvKwE2hBJnABRIup0IWTIkhGDjULK~RlqppTnydbIy-gIGw4SPgGn4yjqwtTM~vQeIVxG2AEJ1Gwp4vDgruxhSMGOI4yJh7rmR1uF3G1mzPUV3iwgN46stwQIYvkmcSxTWk3XCwOy9w__&Key-Pair-Id=K2HSFNDJXOU9YS",
    ],
  },

  // ─── Knitwear / Sweaters ──────────────────────────────────────────────────
  {
    id: "turtleneck-beige",
    name: "Beige Turtleneck",
    category: "Knitwear",
    categorySlug: "knitwear",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["beige", "camel"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Slim-fit turtleneck sweater in a warm beige tone. Crafted from a soft knit blend for a refined, polished look.",
    image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/vnhrQjgAsZekvvzC.jpg?Expires=1804528149&Signature=sSaIHTJIDq4aez~N8ZVIpW0tzOArzDXrZqjwJpLof5mksGWzaY9Ii1z-UonFptSIdlgdclyHRpDxypPUuFW938TJSIWlRPgL3eQLcbEsRGP-UI7O3Ep-pcSb23Mm5Izjp2EDPKZ5ML~diy5bFz7UdkU53J0MPRAXCKBoIy2sKtUs~5a2RUd1Znz0F7yxS~N8IX06~B9bXbBIYnW~-MbYnjQ10l6buOytK-IYSpMgOYeiPN3vcoixJfouEUKFj1QawRS0FXSB3DcUVKP6y4ivLjHs~~GTHcYgxRRoEPSWxa3CU6M6s9ey83xiVeVDTAOa3OEZ2qCQFiVQIPMJASvoYg__&Key-Pair-Id=K2HSFNDJXOU9YS",
    images: [
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/vnhrQjgAsZekvvzC.jpg?Expires=1804528149&Signature=sSaIHTJIDq4aez~N8ZVIpW0tzOArzDXrZqjwJpLof5mksGWzaY9Ii1z-UonFptSIdlgdclyHRpDxypPUuFW938TJSIWlRPgL3eQLcbEsRGP-UI7O3Ep-pcSb23Mm5Izjp2EDPKZ5ML~diy5bFz7UdkU53J0MPRAXCKBoIy2sKtUs~5a2RUd1Znz0F7yxS~N8IX06~B9bXbBIYnW~-MbYnjQ10l6buOytK-IYSpMgOYeiPN3vcoixJfouEUKFj1QawRS0FXSB3DcUVKP6y4ivLjHs~~GTHcYgxRRoEPSWxa3CU6M6s9ey83xiVeVDTAOa3OEZ2qCQFiVQIPMJASvoYg__&Key-Pair-Id=K2HSFNDJXOU9YS",
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/uDkEnNgJXcNkKNDF.jpg?Expires=1804528150&Signature=Wg4CrAmh3-OV6wDlfA5ZDspWqjT886X7iYV3RC50kix54XpzGkuS5t~Dv537nkkF6uTKIoK-vTY46KRqyeOuhQUty~Cz8w0xc0qOCBF7UvATTpmVOMMkXmcooGHoj0verE1DvUoJqTkZ0FwypEm79GM7lYRtGGUTfj2cmoejrbktnBZ6Db7JRFuxVTiA0vVzotUHjzzUMiou8QZ4N33F9WwXgBfrcRvcS1lshIlVdu8z4~Eg8cZJsMl3Zvn1Zszw4NOP67JVOBbzU9Th6DesK9v1mUZpwFE9VjZ6YEot-b6VKycg2kAiitmvtmUAGdbXEHcqRzq6U5ixQvXbLLFMvA__&Key-Pair-Id=K2HSFNDJXOU9YS",
    ],
  },
  {
    id: "sweater-mint",
    name: "Mint Crew Neck Sweater",
    category: "Knitwear",
    categorySlug: "knitwear",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["mint", "green"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Fresh mint crew neck sweater with a slim fit. Soft knit fabric that keeps you warm while looking effortlessly stylish.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/PQTRnGJmnnfFDRlO.jpg",
    images: [
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/PQTRnGJmnnfFDRlO.jpg",
    ],
  },
  {
    id: "sweater-camel-turtleneck",
    name: "Camel Turtleneck Sweater",
    category: "Knitwear",
    categorySlug: "knitwear",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["camel", "brown"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Classic camel turtleneck sweater with a slim silhouette. Premium knit construction for a sophisticated, luxurious feel.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/SOzPnKCsNfZAyKJr.jpg",
    images: [
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/SOzPnKCsNfZAyKJr.jpg",
    ],
  },
  {
    id: "sweater-orange",
    name: "Orange Crew Neck Sweater",
    category: "Knitwear",
    categorySlug: "knitwear",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["orange"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Vibrant orange crew neck sweater with a relaxed fit. A bold statement piece crafted from premium soft-knit fabric.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/sumZpMiBFDwimUnh.jpg",
    images: [
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/sumZpMiBFDwimUnh.jpg",
    ],
  },

  // ─── Tracksuits ───────────────────────────────────────────────────────────
  {
    id: "tracksuit-grey",
    name: "Grey Tracksuit",
    category: "Tracksuits",
    categorySlug: "tracksuits",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["grey"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Premium grey tracksuit set with a matching top and jogger pants. Soft fleece interior with a comfortable relaxed fit.",
    image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/IuXPuIBEdzdRYUFF.jpg?Expires=1804528149&Signature=vD7qiExrz0iQBWZDZIdcfck3MfmAprTAyW9Vhel4etwcMB7bXiAX624k0k7zD7hzkvwqqudoAKI8Wx5LaX9og8VwYaobXLtRwAbm3LTlTfw2o-WRIYIpaTDlfqZww1pLb8YHx-By8Ixe~5Ycxkj91HJQe~koYrg8cy8Ee-u~P7yAM~lvK7LDEIUoedsAlMH8JOl0bjp2Y8cnH8wiw~MCOPaCsYv37wurrSPoCxh6jmo3HR~RWbGAwvFAsUQYlWa21ETLMVwvcgFbPPfIakAO5iDWWDc4OdmyrOzEeAuLc6m8f3RnGcybzCmBsyUx~V~GtHcMvFy-GhN0Ihrexshcag__&Key-Pair-Id=K2HSFNDJXOU9YS",
  },
  {
    id: "tracksuit-green-ribbed",
    name: "Green Ribbed Tracksuit",
    category: "Tracksuits",
    categorySlug: "tracksuits",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["green"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Stylish green ribbed tracksuit with a matching top and jogger pants. Ribbed texture adds a premium look and feel.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/rwonkakEWpfJtGxM.jpg",
    images: [
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/rwonkakEWpfJtGxM.jpg",
    ],
  },

  // ─── Jeans ────────────────────────────────────────────────────────────────
  {
    id: "jeans-grey",
    name: "Grey Ripped Jeans",
    category: "Jeans",
    categorySlug: "jeans",
    oldPrice: 50.99,
    newPrice: 40.99,
    colors: ["grey"],
    sizes: ["28", "30", "32", "34", "36"],
    description: "Distressed grey skinny jeans with heavy rip detailing at the knees. A bold street-style staple that pairs with any top.",
    image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/VsUCuNbVXnyabkfR.jpg?Expires=1804528150&Signature=Lc3IzYA0YrzokEtNE9hiNiXzEeUG8H1JjMO7x08zA1Bn9161KGlCXsjEIc1cTMWk3U~5Bo86M2-xrwnjmJSGwp1QbirnRJ48e-gS3dxBpWrvLGhAM7EnEiH7sgJu4x9-f2eDEMsZhijYBX63JYsFA6TL7q~YbZjcmZv~cJbTv8EvHce5vXFnDnTmMysZ06WSeDj8Xztm6-avJVRb-3phk8ICUzryyFMbSnIweX56EfG42qDgWEn7KEYcn-~cOwRgEGdxJ2U7u-mtcyTeRI8qEC0AU1nwSnecedq-57QIi7wMigznlNS5lk6jGL29ucE0XqH-MsX7q9sdMszi0LjvWA__&Key-Pair-Id=K2HSFNDJXOU9YS",
    images: [
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/VsUCuNbVXnyabkfR.jpg?Expires=1804528150&Signature=Lc3IzYA0YrzokEtNE9hiNiXzEeUG8H1JjMO7x08zA1Bn9161KGlCXsjEIc1cTMWk3U~5Bo86M2-xrwnjmJSGwp1QbirnRJ48e-gS3dxBpWrvLGhAM7EnEiH7sgJu4x9-f2eDEMsZhijYBX63JYsFA6TL7q~YbZjcmZv~cJbTv8EvHce5vXFnDnTmMysZ06WSeDj8Xztm6-avJVRb-3phk8ICUzryyFMbSnIweX56EfG42qDgWEn7KEYcn-~cOwRgEGdxJ2U7u-mtcyTeRI8qEC0AU1nwSnecedq-57QIi7wMigznlNS5lk6jGL29ucE0XqH-MsX7q9sdMszi0LjvWA__&Key-Pair-Id=K2HSFNDJXOU9YS",
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/aJcXnRtFaerEHjBX.jpg?Expires=1804528151&Signature=OMtt3rx2Env1OI96MFtUlHn-x4RC7Wuk7IGuISANmc11SnD-i9aOejL9JTp~7odaYxf6zrqc4uLiEcaLCFr9JYCXhqrEnLSUN87kLExLW-o10w4vIj75qGqaYQypN6~GQoYX0iNQMvG76~Cz1~qvYipTyonGGX1c5-M~J71co~6cW3YioFF6tSWKlRkI5Oml43cXoXChpvZnlOBd9n6JNk9cwm1LaOpAw0H8mMCbGqVjxzFSCmh06xyDUTpy212dTg91swjRuuPStfrqjpuOeQIKPBImm6zKoB0GYDYLa1FLl8-r0o-zCJiEP8Ak-SD5FLHirZELGJLqcOKTc0LfxA__&Key-Pair-Id=K2HSFNDJXOU9YS",
    ],
  },
  {
    id: "jeans-grey-slim",
    name: "Grey Slim Ripped Jeans",
    category: "Jeans",
    categorySlug: "jeans",
    oldPrice: 50.99,
    newPrice: 40.99,
    colors: ["grey"],
    sizes: ["28", "30", "32", "34", "36"],
    description: "Slim-fit grey jeans with strategic rip detailing. A versatile everyday pair that combines comfort with a modern edge.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/xoeAWfqvNdJHZuud.jpg",
    images: [
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/xoeAWfqvNdJHZuud.jpg",
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/QewBXOoFjHwqopxd.jpg",
    ],
  },

  // ─── Shirts ───────────────────────────────────────────────────────────────
  {
    id: "shirt-baroque",
    name: "Baroque Print Shirt",
    category: "Shirts",
    categorySlug: "shirts",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["white", "multicolor"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Luxurious baroque print shirt with an all-over floral pattern. Relaxed fit with a classic button-up front, perfect for a bold statement.",
    image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/BMNlSGdlgEIKBvVC.jpg?Expires=1804528150&Signature=B9cecErd83HyZ8X3cfRF5xietiddImf~XFqdDkYKdN3Tj67LjaSbntYI7sGSBSDye7C8V2bVidO8PJ8A8iveznDJpHNFVFTEV-j3L76X0kzHq8HnpgJ09adf69y5kyoNaGWNIfk4dN8-3oF9O1p2xt~Z48HHf7eotaJgKpF-9yE-AO1mBMPyukyZBE4ExAS7zsk73g4qtCWlCL~2CZmuiRHuo5PgphVuNvx4ZDG5CmWZv-wl4iOttAaWEwzS462ildKeY8tKzgfNX5mW1fyt1FOeoJBnWxP9VNZkjyvw0pAhvDNMU5A0K~9BZlPTwLe2sOxOXVPZ0YLr1z~0WEFj2A__&Key-Pair-Id=K2HSFNDJXOU9YS",
    images: [
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/BMNlSGdlgEIKBvVC.jpg?Expires=1804528150&Signature=B9cecErd83HyZ8X3cfRF5xietiddImf~XFqdDkYKdN3Tj67LjaSbntYI7sGSBSDye7C8V2bVidO8PJ8A8iveznDJpHNFVFTEV-j3L76X0kzHq8HnpgJ09adf69y5kyoNaGWNIfk4dN8-3oF9O1p2xt~Z48HHf7eotaJgKpF-9yE-AO1mBMPyukyZBE4ExAS7zsk73g4qtCWlCL~2CZmuiRHuo5PgphVuNvx4ZDG5CmWZv-wl4iOttAaWEwzS462ildKeY8tKzgfNX5mW1fyt1FOeoJBnWxP9VNZkjyvw0pAhvDNMU5A0K~9BZlPTwLe2sOxOXVPZ0YLr1z~0WEFj2A__&Key-Pair-Id=K2HSFNDJXOU9YS",
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/jvUPEarfnFnYRbEI.jpg?Expires=1804528150&Signature=cut5r8rWUaxig0wPC6kh42BSRpj~dM16-qr33huATY4msonQBdelcDqs5-HATdndQXLbyYa8DMPYW52HFhgfyWa4EeYFNzNCY2r~jII35KUzjQf89~TBnO9lc1DEF~-d~ZFjvqhU-71CI235c-~C7CjizyZnIfLPzZDWWl85vejzJGAW0WKfC4g7cRLCOYKIH4H-w-crai~je81N4nzx6iwL5b~WF1m1Jn7cymYYi-vZuJRFBU7gy5k5u0HIRupXRqx5qmD0~TCXMfkO~uxEbHqyuleZZSQ0QxRC2ysHs85hFjENIg3juTXTEHhPkHWNVf9b3i1MBj98uwxznNtfoA__&Key-Pair-Id=K2HSFNDJXOU9YS",
    ],
  },
  {
    id: "shirt-waffle",
    name: "Waffle Knit Shirt",
    category: "Shirts",
    categorySlug: "shirts",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["beige"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Textured waffle-knit long sleeve shirt with a relaxed fit. Soft and breathable, perfect for casual everyday wear.",
    image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/XIaLtQrHoupfpKeb.jpg?Expires=1804528151&Signature=WsrWpVJXGavHxpDT-m9FC61qDcoKiX9vjP8uHT8Af-SojlXMRkOk3ObJ6N0Xh0YCKKuId9HI8LAZSfCJxKkzTizbBLt5rXBfHLrfuq~ZWVArJoZBQwGA4oXRZ0v8VA7qUEaRVB8hiJqGIfu7pjAgeTPHwaWhTSpkm61Ujo3O~f1QQo9Vi01TsabiKI~LCtXWc7Pc6Wl2RCPjfWFmpvvE4rwW3TyhPNUSbJSdkkKh04xSwFhZ-M2LEZnQFTr2MpkzIq1IhtpovRywUPrDHWAs5b9OR8ArjLXTi3De45ojZAr1OgULCpjs4oMuObm3hxHdb9LS-ScytTUnCu6FVOR4Xg__&Key-Pair-Id=K2HSFNDJXOU9YS",
  },

  // ─── Accessories ──────────────────────────────────────────────────────────

  // ─── New Arrivals (€39.99) ────────────────────────────────────────────────
  {
    id: "coach-jacket-beige-paris",
    name: "Paris Coach Jacket",
    category: "Jackets",
    categorySlug: "jackets",
    oldPrice: 59.99,
    newPrice: 39.99,
    colors: ["beige"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Classic beige coach jacket with an embroidered Eiffel Tower graphic on the chest. Lightweight construction with snap button closure and elasticated cuffs.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/qVPVDQWuQdKvIycM.jpg",
    images: [
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/qVPVDQWuQdKvIycM.jpg",
    ],
  },
  {
    id: "sweater-red-chunky",
    name: "Red Chunky Ribbed Sweater",
    category: "Knitwear",
    categorySlug: "knitwear",
    oldPrice: 59.99,
    newPrice: 39.99,
    colors: ["red"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Bold red chunky ribbed sweater with an oversized crew neck fit. Heavy-weight knit fabric for maximum warmth and a striking street-style look.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/NtAfszkOmPySHfHp.jpg",
    images: [
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/NtAfszkOmPySHfHp.jpg",
    ],
  },
  {
    id: "flannel-jacket-red-plaid",
    name: "Red Plaid Flannel Jacket",
    category: "Jackets",
    categorySlug: "jackets",
    oldPrice: 59.99,
    newPrice: 39.99,
    colors: ["red", "black"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Bold red and black plaid flannel jacket with a zip-up front and hoodie detail. Heavy-weight flannel construction for warmth and a rugged street-style aesthetic.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/EhFKDOsHUVAbrFlH.jpg",
    images: [
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/EhFKDOsHUVAbrFlH.jpg",
    ],
  },


  {
    id: "bag-leather",
    name: "Black Leather Bag",
    category: "Accessories",
    categorySlug: "accessories",
    oldPrice: 50.99,
    newPrice: 20.99,
    colors: ["black"],
    sizes: ["One Size"],
    description: "Sleek black leather shoulder bag with a minimalist design. Spacious interior with multiple compartments for everyday essentials.",
    image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/kHFEjlrgnfvcGvrr.jpg?Expires=1804528150&Signature=lmgXIqZ2bHW4BnEzqAO~qExcvFTt~4z1SBQ5jn2XFaZBgJSKSLCZBDu-RmXc1gSAn~gZ54Ck0q6NxLxlUEPttkv23O0uHRgyDKqg~e-8sObhXWq9TheomgYRQiqZhdjKY~3RVzB6hBLLxpW1Q6AXdKtW7R1ol5UP~nC2mEL6Ny0vf9Q7Mk6vgBLg6OpRCgCCAOa3ldiXqzMxz-ujRR-f6YahEnSsvyEDEt-tXcaQPD6YStzBkgdpLGebGRv60V~dxXoxehi3Xf44Nv~A-GAdj5KHw4x4QgE6F0ZgGMuPQoxkvoJrdpRBJCQMR91mkAJasOL1tD0RmxZSuXawtkyVPQ__&Key-Pair-Id=K2HSFNDJXOU9YS",
    images: [
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/kHFEjlrgnfvcGvrr.jpg?Expires=1804528150&Signature=lmgXIqZ2bHW4BnEzqAO~qExcvFTt~4z1SBQ5jn2XFaZBgJSKSLCZBDu-RmXc1gSAn~gZ54Ck0q6NxLxlUEPttkv23O0uHRgyDKqg~e-8sObhXWq9TheomgYRQiqZhdjKY~3RVzB6hBLLxpW1Q6AXdKtW7R1ol5UP~nC2mEL6Ny0vf9Q7Mk6vgBLg6OpRCgCCAOa3ldiXqzMxz-ujRR-f6YahEnSsvyEDEt-tXcaQPD6YStzBkgdpLGebGRv60V~dxXoxehi3Xf44Nv~A-GAdj5KHw4x4QgE6F0ZgGMuPQoxkvoJrdpRBJCQMR91mkAJasOL1tD0RmxZSuXawtkyVPQ__&Key-Pair-Id=K2HSFNDJXOU9YS",
      "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/eUChDruyeNOFcyvl.jpg?Expires=1804528152&Signature=snxO8xmheLuX6lSHeTH6~2xW9Hqw5tiiNZGwYdGNQWOkoSkxsdlRhWKt~wS4gox7aF4sp7u5QaECI8~f9uKjAyRtM8diZY04pbB6xQXv21qRKM7b2DptfytJtsoSXW1IZ3YF9c9cXxEq~QTJm66aKbLaxuMN28yCMas8ddWnonezCRdGmIkAOaSawMtXJzcggb6AANIUjcZxpghKQ6WMWI4tHNl5n8700IKIwkzQQqDJtTk2HDYoyKhtQ3bpgi5ZzgKNOhYvTdCgmhcEfjqP-xKG5ClY9QIwok2yTv5IXf0bYyNnhKZmwYSmi8jDYlJ0kxgPn4ezaTmneTz67cD89g__&Key-Pair-Id=K2HSFNDJXOU9YS",
    ],
  },
  {
    id: "backpack-grey",
    name: "Grey Backpack",
    category: "Accessories",
    categorySlug: "accessories",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["grey"],
    sizes: ["One Size"],
    description: "Durable grey backpack with multiple compartments. Padded straps and a sleek design make it perfect for daily use.",
    image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/zjaoiPDibaVOrmnQ.jpg?Expires=1804528151&Signature=nMRM9o9cZn-7ybk0hrGQdYYRR9dAwN1h9E1Z9~HMRDMu~fFhBPlOxFfihiIx~jdULOKkoK1-5fO-eSbprbORoHfuqmqCzc3yIm2xrm9lujKYFBkr-1L18hjv9ZHbvqy9qcsIfN7BV2EZ01vO-cSwD27VvM39J0-fs2NoZhchJ-sG3wF7pucBHU1Hrbvhv30V8~MAVJs3kA6CjnN5~0c-x2ca2HENmlXrbAqdL7hJvwV6ztFGojnzCARcUEa~r3OzBzINiv3i~YdHjcB4q2WOvI8hirh9B4fpr6ldRTiX60TqxoxFCShDbjGwgBHmp4hDsh64yb9ammiqumSmXnz02A__&Key-Pair-Id=K2HSFNDJXOU9YS",
  },
  {
    id: "tracksuit-white-turtleneck",
    name: "White Turtleneck Tracksuit",
    category: "Tracksuits",
    categorySlug: "tracksuits",
    oldPrice: 50.99,
    newPrice: 30.99,
    colors: ["white"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    description: "Clean all-white turtleneck tracksuit set with a slim-fit silhouette. Premium soft fabric with a matching jogger — perfect for a sharp, minimalist look.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/rOMBouoBCnBVnBCG.jpg",
    images: [
      "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/rOMBouoBCnBVnBCG.jpg",
    ],
  },
  {
    id: "beanie",
    name: "Classic Beanie",
    category: "Accessories",
    categorySlug: "accessories",
    oldPrice: 35.99,
    newPrice: 20.99,
    colors: ["black", "cream"],
    sizes: ["One Size"],
    description: "Classic ribbed beanie hat crafted from soft premium wool blend. A timeless winter essential available in Black and Cream — select your colour below.",
    isNew: true,
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/rlVEJNOBoIsKcKZC.jpg",
    colorVariants: [
      {
        color: "black",
        label: "Black",
        image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663179755282/rlVEJNOBoIsKcKZC.jpg",
      },
      {
        color: "cream",
        label: "Cream",
        image: "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663414378770/tRqwXWeNNlnLWzDu.jpg?Expires=1804528151&Signature=kjnfAV1lPLm77ttSac~MoE3PGCXPi9EWNTJlFtxbLojd5goJsNHcVWJkdWat6Yedt5y0ZOCsSgC1pt-V4kgOT67rBuVb6NDeZd5C66dGbxxNvckN79SWoawEoByzeXXfXcv9hZIbzDuMt3g-dfJ7mPT8wzzy4c6KNf79IP9JM14hjJ1-IEBSJ8CdnFrTf3utJPAwcKU~0RMs37JgKjHftrNbu8hO80xuV3~zU3wDJPo1BM46BxQWT9G0bkBjfm6X2HbcZ7QCbq7ZoCWNy60m6s9FjK1BWxLs4Ku7Z2A24WnFByoT6dZemt5wG0eaOA8jrzFwvCMhn4hzHkVYx3uZ1g__&Key-Pair-Id=K2HSFNDJXOU9YS",
      },
    ],
  },
];

export function getCategories(): Category[] {
  const categoryMap = new Map<string, Category>();
  PRODUCTS.forEach((product) => {
    if (!categoryMap.has(product.categorySlug)) {
      categoryMap.set(product.categorySlug, {
        name: product.category,
        slug: product.categorySlug,
        products: [],
      });
    }
    categoryMap.get(product.categorySlug)!.products.push(product);
  });
  return Array.from(categoryMap.values());
}

export function getAllColors(): string[] {
  const colors = new Set<string>();
  PRODUCTS.forEach((p) => p.colors?.forEach((c) => colors.add(c)));
  return Array.from(colors).sort();
}

export function getAllSizes(): string[] {
  const order = ["XS", "S", "M", "L", "XL", "XXL", "28", "30", "32", "34", "36", "One Size"];
  const sizes = new Set<string>();
  PRODUCTS.forEach((p) => p.sizes?.forEach((s) => sizes.add(s)));
  return order.filter((s) => sizes.has(s));
}

export default PRODUCTS;
