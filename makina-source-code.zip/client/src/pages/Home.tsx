/**
 * Home Page — Makina Menswear
 * Design: Noir Luxe — Dark Editorial Fashion
 * Sections: Navbar → Hero → Collection → About → Footer
 */

import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import CollectionSection from "@/components/CollectionSection";
import AboutSection from "@/components/AboutSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      <Navbar />
      <main>
        <HeroSection />
        <CollectionSection />
        <AboutSection />
      </main>
      <Footer />
    </div>
  );
}
