/**
 * ProductDetail Page — Makina Menswear
 * Design: Noir Luxe — dark theme product detail with gold accents
 * Features: Large product image, colour variant switcher, sizes, WhatsApp order button
 */

import { useState } from "react";
import { useParams, Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PRODUCTS from "@/lib/products";
import { ArrowLeft, MessageCircle, Ruler, Shield, Truck } from "lucide-react";

const SIZES = ["S", "M", "L", "XL", "XXL"];

// Map colour names → CSS values for swatches
const COLOR_MAP: Record<string, string> = {
  black: "#0A0A0A",
  white: "#F5F5F5",
  grey: "#9E9E9E",
  gray: "#9E9E9E",
  navy: "#1B2A4A",
  blue: "#2563EB",
  red: "#DC2626",
  green: "#16A34A",
  teal: "#0D9488",
  beige: "#C8A97E",
  camel: "#C19A6B",
  brown: "#92400E",
  orange: "#EA580C",
  mint: "#6EE7B7",
  cream: "#FFF8E7",
  pink: "#EC4899",
  purple: "#7C3AED",
  yellow: "#EAB308",
};

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const [selectedSize, setSelectedSize] = useState<string>("");
  const [activeVariantIdx, setActiveVariantIdx] = useState(0);

  const product = PRODUCTS.find((p) => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center pt-20">
          <div className="text-center">
            <h1 className="font-[var(--font-display)] text-3xl text-white mb-4">
              Product Not Found
            </h1>
            <Link
              href="/"
              className="text-[#C9A84C] hover:text-[#E8D48B] transition-colors text-sm tracking-wider uppercase"
            >
              ← Back to Collection
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const hasVariants = !!(product.colorVariants && product.colorVariants.length > 0);
  const activeVariant = hasVariants ? product.colorVariants![activeVariantIdx] : null;

  // Image to display
  const displayImage = activeVariant ? activeVariant.image : product.image;
  const activeColorLabel = activeVariant ? activeVariant.label : null;

  const description =
    product.description ||
    "Premium quality menswear crafted from high-quality materials. Designed for the modern man who values style and comfort.";

  const whatsappMessage = `Hi! I'm interested in ordering the ${product.name}${activeColorLabel ? ` in ${activeColorLabel}` : ""}${selectedSize ? `, size ${selectedSize}` : ""}. Price: €${product.newPrice.toFixed(2)}`;
  const whatsappUrl = `https://wa.me/31657505640?text=${encodeURIComponent(whatsappMessage)}`;

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex flex-col">
      <Navbar />

      <main className="flex-1 pt-20 lg:pt-24">
        {/* Breadcrumb */}
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link
            href="/shop"
            className="inline-flex items-center gap-2 text-[#888] hover:text-[#C9A84C] transition-colors text-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="tracking-wider uppercase text-xs">Back to Shop</span>
          </Link>
        </div>

        {/* Product Content */}
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 pb-16 lg:pb-24">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-16">

            {/* ── Left: Product Image ─────────────────────────────────── */}
            <div className="relative">
              <div className="aspect-[3/4] bg-[#f5f5f5] overflow-hidden sticky top-24">
                {/* Badges */}
                <div className="absolute top-4 left-4 z-10 flex flex-col gap-1">
                  {product.isNew && (
                    <span className="bg-[#0A0A0A] px-3 py-1.5 text-[11px] tracking-wider text-white font-bold uppercase">
                      New
                    </span>
                  )}
                  <span className="bg-[#C9A84C] px-3 py-1.5 text-[11px] tracking-wider text-[#0A0A0A] font-bold uppercase">
                    Sale
                  </span>
                </div>

                <img
                  key={displayImage}
                  src={displayImage}
                  alt={`${product.name}${activeColorLabel ? ` — ${activeColorLabel}` : ""}`}
                  className="w-full h-full object-cover object-top transition-opacity duration-500"
                />
              </div>
            </div>

            {/* ── Right: Product Info ─────────────────────────────────── */}
            <div className="lg:py-4">
              {/* Category */}
              <span className="text-[11px] tracking-[0.3em] text-[#C9A84C] uppercase font-medium">
                {product.category}
              </span>

              {/* Product Name */}
              <h1 className="font-[var(--font-display)] text-2xl sm:text-3xl lg:text-4xl font-bold text-white mt-3 mb-6 leading-tight">
                {product.name}
              </h1>

              {/* Price */}
              <div className="flex items-baseline gap-4 mb-8">
                <span className="text-lg text-[#666] line-through">
                  €{product.oldPrice.toFixed(2)}
                </span>
                <span className="font-[var(--font-display)] text-3xl font-bold gold-text">
                  €{product.newPrice.toFixed(2)}
                </span>
              </div>

              {/* Divider */}
              <div className="w-full h-px bg-white/10 mb-8" />

              {/* Description */}
              <p className="text-[#999] text-sm leading-relaxed mb-8">
                {description}
              </p>

              {/* ── Colour Variants ──────────────────────────────────── */}
              {hasVariants && (
                <div className="mb-8">
                  <h3 className="text-xs tracking-[0.2em] text-white uppercase font-semibold mb-4">
                    Colour:{" "}
                    <span className="text-[#C9A84C] normal-case tracking-normal font-normal">
                      {product.colorVariants![activeVariantIdx].label}
                    </span>
                  </h3>
                  <div className="flex items-center gap-3 flex-wrap">
                    {product.colorVariants!.map((variant, idx) => {
                      const cssColor =
                        COLOR_MAP[variant.color.toLowerCase()] ?? variant.color;
                      const isActive = idx === activeVariantIdx;
                      return (
                        <button
                          key={variant.color}
                          title={variant.label}
                          onClick={() => setActiveVariantIdx(idx)}
                          className={`w-8 h-8 rounded-full border-2 transition-all duration-200 relative ${
                            isActive
                              ? "border-[#C9A84C] scale-110 shadow-lg shadow-[#C9A84C]/30"
                              : "border-white/20 hover:border-[#C9A84C]/60"
                          }`}
                          style={{ backgroundColor: cssColor }}
                        >
                          {isActive && (
                            <span className="absolute inset-0 rounded-full ring-2 ring-[#C9A84C] ring-offset-2 ring-offset-[#0A0A0A]" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* ── Size Selection ───────────────────────────────────── */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xs tracking-[0.2em] text-white uppercase font-semibold">
                    Select Size
                  </h3>
                  <button className="flex items-center gap-1.5 text-[11px] text-[#C9A84C] hover:text-[#E8D48B] transition-colors tracking-wider uppercase">
                    <Ruler className="w-3.5 h-3.5" />
                    Size Guide
                  </button>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {(product.sizes || SIZES).map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`py-3 text-sm font-medium tracking-wider transition-all duration-300 border ${
                        selectedSize === size
                          ? "border-[#C9A84C] bg-[#C9A84C]/10 text-[#C9A84C]"
                          : "border-white/10 text-[#aaa] hover:border-[#C9A84C]/50 hover:text-white"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* WhatsApp Order Button */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 w-full py-4 bg-[#25D366] hover:bg-[#20BD5A] text-white font-semibold text-sm tracking-wider uppercase transition-all duration-300 mb-4"
              >
                <MessageCircle className="w-5 h-5" />
                Order via WhatsApp
              </a>

              {/* Email CTA */}
              <a
                href={`mailto:marksafarnl@gmail.com?subject=Order: ${product.name}&body=${whatsappMessage}`}
                className="flex items-center justify-center gap-3 w-full py-4 border border-[#C9A84C] text-[#C9A84C] hover:bg-[#C9A84C]/10 font-semibold text-sm tracking-wider uppercase transition-all duration-300 mb-8"
              >
                Order via Email
              </a>

              {/* Features */}
              <div className="space-y-4 pt-4 border-t border-white/10">
                <div className="flex items-center gap-3">
                  <Truck className="w-4 h-4 text-[#C9A84C]" />
                  <span className="text-sm text-[#999]">Fast shipping across Europe</span>
                </div>
                <div className="flex items-center gap-3">
                  <Shield className="w-4 h-4 text-[#C9A84C]" />
                  <span className="text-sm text-[#999]">Premium quality guaranteed</span>
                </div>
                <div className="flex items-center gap-3">
                  <MessageCircle className="w-4 h-4 text-[#C9A84C]" />
                  <span className="text-sm text-[#999]">Direct contact: +31 6 57505640</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
