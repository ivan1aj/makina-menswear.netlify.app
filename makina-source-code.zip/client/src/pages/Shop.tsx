import { useState, useMemo } from "react";
import { Link } from "wouter";
import PRODUCTS, { getAllColors, getAllSizes } from "../lib/products";
import ProductCard from "../components/ProductCard";

const CATEGORY_LABELS: Record<string, string> = {
  jackets: "Jackets",
  hoodies: "Hoodies",
  knitwear: "Knitwear",
  tracksuits: "Tracksuits",
  jeans: "Jeans",
  shirts: "Shirts",
  accessories: "Accessories",
};

const CATEGORY_ICONS: Record<string, string> = {
  jackets: "🧥",
  hoodies: "👕",
  knitwear: "🧶",
  tracksuits: "🏃",
  jeans: "👖",
  shirts: "👔",
  accessories: "🎩",
};

const COLOR_HEX: Record<string, string> = {
  black: "#1a1a1a",
  white: "#f5f5f5",
  grey: "#9ca3af",
  blue: "#3b82f6",
  red: "#ef4444",
  green: "#22c55e",
  camel: "#c19a6b",
  beige: "#d4b896",
  brown: "#92400e",
  orange: "#f97316",
  mint: "#6ee7b7",
  cream: "#fef3c7",
  teal: "#14b8a6",
  multicolor: "linear-gradient(135deg,#ef4444,#3b82f6,#22c55e)",
};

export default function Shop() {
  const allColors = getAllColors();
  const allSizes = getAllSizes();

  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 60]);
  const [sortBy, setSortBy] = useState("featured");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleCategory = (slug: string) => {
    setSelectedCategories((prev) =>
      prev.includes(slug) ? prev.filter((c) => c !== slug) : [...prev, slug]
    );
  };
  const toggleColor = (color: string) => {
    setSelectedColors((prev) =>
      prev.includes(color) ? prev.filter((c) => c !== color) : [...prev, color]
    );
  };
  const toggleSize = (size: string) => {
    setSelectedSizes((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]
    );
  };

  const clearAll = () => {
    setSelectedCategories([]);
    setSelectedColors([]);
    setSelectedSizes([]);
    setPriceRange([0, 60]);
  };

  const filtered = useMemo(() => {
    let result = PRODUCTS.filter((p) => {
      if (selectedCategories.length && !selectedCategories.includes(p.categorySlug)) return false;
      if (selectedColors.length && !p.colors?.some((c) => selectedColors.includes(c))) return false;
      if (selectedSizes.length && !p.sizes?.some((s) => selectedSizes.includes(s))) return false;
      if (p.newPrice < priceRange[0] || p.newPrice > priceRange[1]) return false;
      return true;
    });

    if (sortBy === "price-asc") result = [...result].sort((a, b) => a.newPrice - b.newPrice);
    else if (sortBy === "price-desc") result = [...result].sort((a, b) => b.newPrice - a.newPrice);
    else if (sortBy === "new") result = [...result].sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));

    return result;
  }, [selectedCategories, selectedColors, selectedSizes, priceRange, sortBy]);

  const activeFiltersCount =
    selectedCategories.length + selectedColors.length + selectedSizes.length +
    (priceRange[0] > 0 || priceRange[1] < 60 ? 1 : 0);

  const FilterSidebar = () => (
    <aside className="w-full lg:w-72 flex-shrink-0">
      <div className="sticky top-24 space-y-0 overflow-hidden rounded-xl border border-white/8"
        style={{ background: "linear-gradient(160deg, #111 0%, #0d0d0d 100%)" }}>

        {/* Sidebar Header */}
        <div className="px-6 py-5 border-b border-white/6 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <svg className="w-4 h-4 text-[#C9A84C]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 4h18M7 8h10M11 12h4" />
            </svg>
            <h2 className="text-white font-semibold text-xs uppercase tracking-[0.2em]">Refine</h2>
          </div>
          {activeFiltersCount > 0 && (
            <button
              onClick={clearAll}
              className="text-[10px] text-[#C9A84C] hover:text-[#E8D48B] transition-colors uppercase tracking-wider"
            >
              Clear ({activeFiltersCount})
            </button>
          )}
        </div>

        {/* Category */}
        <div className="px-6 py-5 border-b border-white/6">
          <h3 className="text-[#C9A84C] text-[10px] uppercase tracking-[0.3em] mb-4 font-semibold">Category</h3>
          <div className="space-y-1">
            {Object.entries(CATEGORY_LABELS).map(([slug, label]) => {
              const count = PRODUCTS.filter((p) => p.categorySlug === slug).length;
              const isActive = selectedCategories.includes(slug);
              return (
                <button
                  key={slug}
                  onClick={() => toggleCategory(slug)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-all duration-200 text-left ${
                    isActive
                      ? "bg-[#C9A84C]/15 border border-[#C9A84C]/30"
                      : "hover:bg-white/4 border border-transparent"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-base leading-none">{CATEGORY_ICONS[slug]}</span>
                    <span className={`text-sm font-medium transition-colors ${isActive ? "text-[#C9A84C]" : "text-zinc-400"}`}>
                      {label}
                    </span>
                  </div>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${isActive ? "bg-[#C9A84C]/20 text-[#C9A84C]" : "text-zinc-600"}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Price Range */}
        <div className="px-6 py-5 border-b border-white/6">
          <h3 className="text-[#C9A84C] text-[10px] uppercase tracking-[0.3em] mb-4 font-semibold">Price Range</h3>
          <div className="flex items-center justify-between mb-3">
            <span className="text-white text-sm font-semibold">€{priceRange[0]}</span>
            <span className="text-zinc-500 text-xs">—</span>
            <span className="text-white text-sm font-semibold">€{priceRange[1]}</span>
          </div>
          <div className="relative">
            <input
              type="range"
              min={0}
              max={60}
              step={1}
              value={priceRange[1]}
              onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
              className="w-full h-1 appearance-none rounded-full cursor-pointer"
              style={{
                background: `linear-gradient(to right, #C9A84C 0%, #C9A84C ${(priceRange[1] / 60) * 100}%, #333 ${(priceRange[1] / 60) * 100}%, #333 100%)`
              }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-zinc-600 mt-2">
            <span>€0</span>
            <span>€60</span>
          </div>
        </div>

        {/* Size */}
        <div className="px-6 py-5 border-b border-white/6">
          <h3 className="text-[#C9A84C] text-[10px] uppercase tracking-[0.3em] mb-4 font-semibold">Size</h3>
          <div className="flex flex-wrap gap-2">
            {allSizes.map((size) => (
              <button
                key={size}
                onClick={() => toggleSize(size)}
                className={`px-3 py-1.5 text-[11px] font-medium rounded-md border transition-all duration-200 ${
                  selectedSizes.includes(size)
                    ? "bg-[#C9A84C] border-[#C9A84C] text-black shadow-lg shadow-[#C9A84C]/20"
                    : "border-zinc-800 text-zinc-400 hover:border-zinc-600 hover:text-white"
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>

        {/* Color */}
        <div className="px-6 py-5">
          <h3 className="text-[#C9A84C] text-[10px] uppercase tracking-[0.3em] mb-4 font-semibold">Colour</h3>
          <div className="flex flex-wrap gap-3">
            {allColors.map((color) => {
              const hex = COLOR_HEX[color] || "#888";
              const isGradient = hex.startsWith("linear");
              const isSelected = selectedColors.includes(color);
              return (
                <button
                  key={color}
                  onClick={() => toggleColor(color)}
                  title={color.charAt(0).toUpperCase() + color.slice(1)}
                  className={`relative w-8 h-8 rounded-full transition-all duration-200 hover:scale-110 ${
                    isSelected ? "ring-2 ring-[#C9A84C] ring-offset-2 ring-offset-[#0d0d0d] scale-110" : ""
                  }`}
                  style={isGradient ? { background: hex } : { backgroundColor: hex, border: color === "white" || color === "cream" ? "1px solid #333" : "none" }}
                />
              );
            })}
          </div>
        </div>
      </div>
    </aside>
  );

  return (
    <div className="min-h-screen bg-[#080808] pt-20">
      {/* Elegant Page Header */}
      <div className="relative overflow-hidden border-b border-white/6">
        <div className="absolute inset-0 bg-gradient-to-r from-[#C9A84C]/5 via-transparent to-transparent" />
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
          <div className="flex items-end justify-between">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-6 h-[1px] bg-[#C9A84C]" />
                <span className="text-[#C9A84C] text-[10px] uppercase tracking-[0.35em] font-medium">Makina Menswear</span>
              </div>
              <h1 className="font-[var(--font-display)] text-3xl lg:text-5xl font-bold text-white tracking-tight">
                The Collection
              </h1>
              <p className="text-zinc-500 text-sm mt-2 max-w-sm">
                Premium men's fashion — curated for those who demand excellence.
              </p>
            </div>
            <div className="hidden lg:flex flex-col items-end gap-1">
              <span className="text-3xl font-bold text-white">{filtered.length}</span>
              <span className="text-zinc-600 text-xs uppercase tracking-widest">Pieces</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-8">
          {/* Sidebar — desktop */}
          <div className="hidden lg:block">
            <FilterSidebar />
          </div>

          {/* Main content */}
          <div className="flex-1 min-w-0">
            {/* Toolbar */}
            <div className="flex items-center justify-between mb-8 gap-4">
              {/* Mobile filter button */}
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden flex items-center gap-2 px-4 py-2.5 border border-zinc-800 rounded-lg text-zinc-300 text-sm hover:border-[#C9A84C]/50 hover:text-[#C9A84C] transition-all"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4h18M7 8h10M11 12h4" />
                </svg>
                Filters
                {activeFiltersCount > 0 && (
                  <span className="bg-[#C9A84C] text-black text-[10px] rounded-full w-4 h-4 flex items-center justify-center font-bold">
                    {activeFiltersCount}
                  </span>
                )}
              </button>

              {/* Active filter chips */}
              <div className="flex flex-wrap gap-2 flex-1">
                {selectedCategories.map((slug) => (
                  <span key={slug} className="flex items-center gap-1.5 px-3 py-1 bg-[#C9A84C]/10 border border-[#C9A84C]/25 text-[#C9A84C] text-[11px] rounded-full">
                    {CATEGORY_LABELS[slug]}
                    <button onClick={() => toggleCategory(slug)} className="text-[#C9A84C]/60 hover:text-[#C9A84C] ml-0.5 text-xs leading-none">×</button>
                  </span>
                ))}
                {selectedColors.map((color) => (
                  <span key={color} className="flex items-center gap-1.5 px-3 py-1 bg-zinc-900 border border-zinc-700 text-zinc-300 text-[11px] rounded-full capitalize">
                    <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: COLOR_HEX[color] || "#888" }} />
                    {color}
                    <button onClick={() => toggleColor(color)} className="text-zinc-500 hover:text-white ml-0.5 text-xs leading-none">×</button>
                  </span>
                ))}
                {selectedSizes.map((size) => (
                  <span key={size} className="flex items-center gap-1.5 px-3 py-1 bg-zinc-900 border border-zinc-700 text-zinc-300 text-[11px] rounded-full">
                    {size}
                    <button onClick={() => toggleSize(size)} className="text-zinc-500 hover:text-white ml-0.5 text-xs leading-none">×</button>
                  </span>
                ))}
              </div>

              {/* Sort */}
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="bg-[#111] border border-zinc-800 text-zinc-300 text-xs rounded-lg px-3 py-2.5 focus:outline-none focus:border-[#C9A84C]/50 cursor-pointer hover:border-zinc-600 transition-colors min-w-[160px]"
              >
                <option value="featured">Featured</option>
                <option value="new">New Arrivals</option>
                <option value="price-asc">Price: Low → High</option>
                <option value="price-desc">Price: High → Low</option>
              </select>
            </div>

            {/* Product Grid */}
            {filtered.length === 0 ? (
              <div className="text-center py-32">
                <div className="w-16 h-16 rounded-full bg-zinc-900 flex items-center justify-center mx-auto mb-4">
                  <svg className="w-7 h-7 text-zinc-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                <p className="text-zinc-500 text-base mb-1">No products match your filters</p>
                <p className="text-zinc-700 text-sm mb-4">Try adjusting or clearing your selection</p>
                <button
                  onClick={clearAll}
                  className="text-[#C9A84C] text-sm hover:text-[#E8D48B] transition-colors border border-[#C9A84C]/30 px-5 py-2 rounded-lg hover:border-[#C9A84C]/60"
                >
                  Clear all filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-10">
                {filtered.map((product, index) => (
                  <ProductCard key={product.id} product={product} index={index} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Sidebar Drawer */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setSidebarOpen(false)}
          />
          <div className="absolute right-0 top-0 h-full w-80 bg-[#0a0a0a] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between px-6 py-5 border-b border-white/6">
              <h2 className="text-white font-semibold text-xs uppercase tracking-[0.2em]">Refine Results</h2>
              <button
                onClick={() => setSidebarOpen(false)}
                className="text-zinc-400 hover:text-white transition-colors w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/5"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="p-4">
              <FilterSidebar />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
